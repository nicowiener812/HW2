package com.example.hw2;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class AddMessageActivity extends AppCompatActivity {

    private static final int REQUEST_PERMISSIONS_CODE = 1;
    private final FirebaseFirestore db = FirebaseFirestore.getInstance();
    private ImageView addPhotoImageView;
    private Uri currentImageUri;
    private ActivityResultLauncher<Uri> takePictureLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_message);

        addPhotoImageView = findViewById(R.id.addPhotoImageView);

        takePictureLauncher = registerForActivityResult(new ActivityResultContracts.TakePicture(), result -> {
            if (result) {
                addPhotoImageView.setImageURI(currentImageUri);
            } else {
                Toast.makeText(this, "Failed to take picture", Toast.LENGTH_SHORT).show();
            }
        });

        addPhotoImageView.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(AddMessageActivity.this, new String[]{
                        Manifest.permission.CAMERA,
                        Manifest.permission.ACCESS_MEDIA_LOCATION
                }, REQUEST_PERMISSIONS_CODE);
            } else {
                captureImage();
            }
        });

        Button submitButton = findViewById(R.id.button);
        submitButton.setOnClickListener(v -> uploadData());
    }

    private void captureImage() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera");
        currentImageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        takePictureLauncher.launch(currentImageUri);
    }

    private void uploadData() {
        EditText nameEditText = findViewById(R.id.name);
        EditText textEditText = findViewById(R.id.text);
        String name = nameEditText.getText().toString().trim();
        String text = textEditText.getText().toString().trim();

        if (name.isEmpty() || text.isEmpty()) {
            Toast.makeText(this, "Please enter both name and text", Toast.LENGTH_SHORT).show();
            return;
        }

        StorageReference storageRef = FirebaseStorage.getInstance().getReference();
        StorageReference fileRef = storageRef.child("images/" + System.currentTimeMillis() + ".jpg");

        if (currentImageUri != null) {
            fileRef.putFile(currentImageUri).addOnSuccessListener(taskSnapshot -> fileRef.getDownloadUrl().addOnSuccessListener(uri -> saveMessageToDatabase(name, text, uri.toString()))).addOnFailureListener(e -> Toast.makeText(AddMessageActivity.this, "Failed to upload image", Toast.LENGTH_SHORT).show());
        } else {
            saveMessageToDatabase(name, text, null);
        }
    }

    private void saveMessageToDatabase(String name, String text, @NonNull String imageUrl) {
        Message message = new Message(imageUrl, name, text);
        db.collection("Messages").document(message.ID).set(message.getAsMap())
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(AddMessageActivity.this, "Message added", Toast.LENGTH_SHORT).show();
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("message", message);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(AddMessageActivity.this, "Failed to add message", Toast.LENGTH_SHORT).show());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            captureImage();
        } else {
            Toast.makeText(this, "Camera permission is required to take a picture", Toast.LENGTH_SHORT).show();
        }
    }
}
